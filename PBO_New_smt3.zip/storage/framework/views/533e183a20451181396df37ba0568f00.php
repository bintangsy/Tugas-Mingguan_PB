

<?php $__env->startSection('content'); ?>
<h1 class="text-center"> Data Mahasiswa</h1>
    <div class="row">
        <a href="/tambahmahasiswa"
        <button type="button" class="btn btn-success">Tambah Data</button>
        </a>
<br>
<?php if($message = Session::get('success')): ?>
    <div class="alert alert-success" role="alert">
        <?php echo e($message); ?>

    </div>
<?php endif; ?>
        <table class="table">
  <thead>
    <tr>
      <th scope="col">No</th>
      <th scope="col">Nama</th>
      <th scope="col">NIM</th>
      <th scope="col">Program Studi</th>
      <th scope="col">Email</th>
      <th scope="col">no. Hp</th>
      <th scope="col">AKSI</th>
    </tr>
  </thead>
  <tbody>
    <?php $i=1 ?>
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mahasiswa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <th scope="row"><?php echo $i?></th>
        <td><?php echo e($mahasiswa["name"]); ?></td>
        <td><?php echo e($mahasiswa["nim"]); ?></td>
        <td><?php echo e($mahasiswa["prodi"]); ?></td>
        <td><?php echo e($mahasiswa["email"]); ?></td>
        <td><?php echo e($mahasiswa["nohp"]); ?></td>
        <td>
            <a href="tampildata/<?php echo e($mahasiswa['id']); ?>" class="btn btn-primary">EDIT</a>
            <a href="deletedata/<?php echo e($mahasiswa['id']); ?>" class="btn btn-danger" onclick="return conform('yakin ingin menghapus data ini?')">HAPUS</a>"
        </td>
        <?php $i++?>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Bintang_PBW_TI24\PBO_New_smt3\resources\views/Mahasiswa.blade.php ENDPATH**/ ?>